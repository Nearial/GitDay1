package PresentationLayer;

import java.sql.*;
import java.util.ArrayList;
import DBAccess.Connector;

public class customerList {

    public static ArrayList<String> listOfCustomers() {

            ArrayList<String> customers = new ArrayList();

        try {
            Connection con = Connector.connection();
            String statement = "SELECT * FROM users Where role = 'customer'";
            PreparedStatement ps = Connector.connection().prepareStatement(statement);
            ResultSet rs = ps.executeQuery();

            while(rs.next()) {
                customers.add(rs.getString("email"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        return customers;
    }
}
